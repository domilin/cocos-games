
declare interface String {
    format(...agrs: any[]): string;
    parseColor(): any;
}