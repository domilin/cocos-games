import { _decorator, tween, Vec3, v3,Sprite } from 'cc';
import { comm } from '../../easyFramework/mgr/comm';
const { ccclass, property } = _decorator;

@ccclass('RedPoint')
export class RedPoint extends comm {
   
 
  

  
}

