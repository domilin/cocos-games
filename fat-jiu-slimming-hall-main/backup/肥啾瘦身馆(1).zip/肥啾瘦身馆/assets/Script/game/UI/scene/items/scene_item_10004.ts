import { _decorator, Component, Node, Vec2, v2 } from 'cc';
import { scene_item_parent } from '../scene_item_parent';
const { ccclass, property } = _decorator;

/**
 * 粉色跑步机
 */
@ccclass('scene_item_10004')
export class scene_item_10004 extends scene_item_parent {

    start(){
        super.start()
    }

}


