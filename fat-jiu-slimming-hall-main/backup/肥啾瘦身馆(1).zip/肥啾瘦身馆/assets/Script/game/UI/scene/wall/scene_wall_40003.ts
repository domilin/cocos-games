import { _decorator, Component, Node, Vec2, v2 } from 'cc';
import { scene_item_parent } from '../scene_item_parent';
const { ccclass, property } = _decorator;

/**
 * 肥啾地毯
 */
@ccclass('scene_wall_40003')
export class scene_wall_40003 extends scene_item_parent {
  
    start(){
        super.start()
    }

}


