import { _decorator, Component, Node, Vec2, v2 } from 'cc';
import { scene_item_parent } from '../scene_item_parent';
const { ccclass, property } = _decorator;

/**
 * 肥啾地毯
 */
@ccclass('scene_item_20001')
export class scene_item_20001 extends scene_item_parent {
  
    start(){
        super.start()
    }

}


