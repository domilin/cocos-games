import { _decorator } from "cc";

const { ccclass, property } = _decorator;


@ccclass('AdManager')
export class AdManager {



}

