
export const tyqConstants = {

    paths: {
        layer: "layer/",
    },

    bundles: {
        tyqSDKBundle: "tyqSDKBundle",
    },

    layers: {
        TyqMoreGameLayer: "TyqMoreGameLayer",
    }
}
