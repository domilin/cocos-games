import { Node, _decorator } from 'cc';
import { tyqSDK } from '../../tyqSDK';
import { tyqSDKConfig } from '../../tyqSDKConfig';
import { TyqBaseLayer } from './TyqBaseLayer';
const { ccclass, property } = _decorator;

@ccclass('TyqMoreGameLayer')
export class TyqMoreGameLayer extends TyqBaseLayer {

    private level: number = 0;

    private isShowBanner: boolean = false;
    private lastBannerShow: boolean = false;

    onLoad() {
        super.onLoad();

        this.level = this.obj.level;

        this.lastBannerShow = tyqSDK.isBannerAdShowing();
        tyqSDK.hideBannerAd();

        tyqSDK.showCustomHorizontalTopAd(true);
        tyqSDK.showCustomRectCenterAd();
    }

    onButtonClick(node: Node, name: string) {
        switch (name) {
            case "btnGoOn":
                this.onClickBtnGoOn(node);
                break;
            default:
                break;
        }
    }

    onClickBtnGoOn(node: Node) {
        let val = tyqSDK.getSwitchValue(tyqSDKConfig.paramsKeys.tyq_banner_touch);
        if (val && this.level > parseInt(val)) {
            if (!this.isShowBanner) {
                this.isShowBanner = true;
                tyqSDK.showBannerAd();
                this.scheduleOnce(() => {
                    tyqSDK.hideBannerAd();
                }, 1.5 + Math.random());
                return;
            }
        }

        this.unscheduleAllCallbacks();
        this.closeLayer();
        if (this.cb) {
            this.cb();
        }

        if (this.lastBannerShow) {
            tyqSDK.showBannerAd();
        }

    }

}

