import { _decorator, Component, Node , sys, director} from 'cc';
import { tyqSDK } from '../tyqSDK';
import { GNetConf } from './conf';
const { ccclass, property } = _decorator;

@ccclass('TimeCtr')
export default class TimeCtr extends Component{

    private static instance:TimeCtr = null!;

    public static GetInstance(){
        if (!this.instance) {
            this.instance = new TimeCtr();
            this.instance.InitTimeCtr();
        }
        return this.instance;
    }

    urls:string[] = [
        
       
    ];

    public serverTime:number = 0;
    public diffServerTime:number = 0;
    public isRunServerTime:boolean =false;
    loginTime:string = '';
    public curSystemDate = 0;
    
    InitTimeCtr(){

    }

    UpdateServerTime(time:number){
        director.getScheduler().unschedule(this.updateTimer,this)
        // time = new Date().getTime();// 修改服务器时间为本地进行测试 !!
        this.serverTime = time;
        this.curSystemDate = time;
        // console.log("date:",new Date(time))
        director.getScheduler().schedule(this.updateTimer, this, 1);
        // let now = new Date(time);
        // console.log("now:",now,now.getFullYear(),now.getMonth()+1,now.getDate(),"星期:"+now.getDay())
    }

    UpdateServerTimeByHeartbeat(time:number){
        // console.warn("---时间同步----", time)
        this.serverTime = time;
        this.curSystemDate = time;
    }

    ReInit(){
       director.getScheduler().unschedule(this.updateTimer,this)
    }

    public updateTimer() {
		// this.serverTime += 1000;
        this.isRunServerTime = true;
        // 检查是否隔天了..
        // if (App.center.GetNowDateString() != this.loginTime && this.loginTime != '') {
        //     App.Instance.InitCtr();
        //     this.loginTime = App.center.GetNowDateString();
        // }
	}

    get ServerTime(){
        if (this.serverTime != 0) {
            return this.serverTime;
        }
        return Date.now();
    }

    get ServerDate(){
        if (this.serverTime != 0) {
            return new Date(this.serverTime);
        }
    }

    public async RequestTime(call:Function) {
        for (let i = 0; i < this.urls.length; i++) {
            const url = this.urls[i];
            let isOk = false;
            let result:any = {};
            await this.request(url).then((r)=>{
                isOk = true;
                result = r;
            }).catch((r)=>{
                isOk = false;
                result = r;
            })

            if (isOk) {
                call(result);
                return;
            }
        }

        call({result:false});
		
	}


    private request(url:string){
       
    }



}
